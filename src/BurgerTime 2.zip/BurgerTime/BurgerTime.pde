ArrayList<Ladder> ladders;
Ingredients i1;
Chef c1;
Enemy e1;
Ladder l1;
Info p1;

void setup() {
  i1 = new Ingredients();
  c1 = new Chef();
  e1 = new Enemy();
  ladders = new ArrayList<Ladder>();
  ladders.add(new Ladder(width/2, height-10, 16, 15,8,0+8,120+8));
  ladders.add(new Ladder(40, height-10, 16, 15,11,0+8,150+8));
  ladders.add(new Ladder(70, height-10, 16, 15,1,0+8,15+8));
  p1 = new Info();
  size(256, 240);
}

void draw() {
  background(0);
  for (Ladder l : ladders) {
    l.display();
  }
  i1.display();
  c1.display();
  e1.display();
  p1.display();
  c1.move();
}
